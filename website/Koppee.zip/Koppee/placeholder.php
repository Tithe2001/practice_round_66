
<?PHP 


if(isset($_GET ["page"])){
    $abc= $_GET ["page"];


if( $abc== "about"){
    include ("pages/about.php");
}
elseif($abc== "contact"){
   include ("pages/contact.php"); 
}
elseif($abc== ""){
   include ("pages/.php"); 
}
elseif($abc== ""){
   include ("pages/.php"); 
}
elseif($abc== ""){
   include ("pages/.php"); 
}
elseif($abc== ""){
   include ("pages/.php"); 
}
elseif($abc== ""){
   include ("pages/.php"); 
}

}


?>